package com.example.inclass;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.gson.Gson;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private EditText edittext1;
    private EditText edittext2;
    private Button btnAdd;
    private SharedPreferences Prefs;
    private SharedPreferences.Editor editor;
    ArrayList<Employee> Employees= new ArrayList<>();




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        edittext1= findViewById(R.id.name);
        edittext2= findViewById(R.id.salary);
        SetUp();
    }

    private void SetUp(){
        Prefs= PreferenceManager.getDefaultSharedPreferences(this);
        editor= Prefs.edit();
    }

    public void addbtn(View view) {
        SetUp();
        Gson gson= new Gson();
        String name= edittext1.getText().toString().trim();
        int salary= Integer.parseInt(edittext2.getText().toString().trim());
        Employees.add(new Employee(name,salary));
        String str= gson.toJson(Employees);
        editor.putString("",str);
        editor.commit();
        Toast.makeText(this, "Has Been Added"
                +str, Toast.LENGTH_SHORT).show();



    }



}
